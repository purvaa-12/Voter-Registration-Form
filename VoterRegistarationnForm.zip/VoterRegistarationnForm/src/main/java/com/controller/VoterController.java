package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.entity.VoterForm;

@Controller
public class VoterController {
	@RequestMapping(path="/")
	public String getIndexPage() {
		return "index";
		
	}
	@RequestMapping(path="/registerForm")
	public String getRegisterForm() {
		return "registerForm";
	}
	@RequestMapping(path="/registerSuccessfully",method = RequestMethod.POST)
	public String registrationSuccessPage(@ModelAttribute VoterForm vf) {
		return "success";
	}
}
